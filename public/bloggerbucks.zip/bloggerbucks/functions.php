<?php

/**
 * Get the links that should display
 *
 * @return array
 */
function bloggerbucks_links_get_links()
{
    if (gadget_links_should_load_from_cache()) {
        if (gadget_links_get_debug_mode()) {
            echo 'Loading from cache.';
        }

        return bloggerbucks_links_load_from_cache();
    }

    if (gadget_links_get_debug_mode()) {
        echo 'Loading from API.';
    }

    try {
        $linksApi = new BloggerBucksLinksApi();

        $links = $linksApi->getLinks();
    } catch (BloggerBucksApiException $e) {
        if (gadget_links_get_debug_mode()) {
            echo 'Error getting links. ' . $e->getMessage();
        }

        return [];
    }

    update_option('bloggerbucks_links_last_updated', time());
    update_option('bloggerbucks_links_cache', $links);

    return $links;
}

/**
 * Get debug mode option value
 *
 * @return bool
 */
function gadget_links_get_debug_mode()
{
    $options = get_option('bloggerbucks_links');

    if (!empty($options['debug_mode']) && $options['debug_mode'] == 1) {
        return true;
    }

    return false;
}

/**
 * Check if it should load links from cache
 *
 * @return bool
 */
function gadget_links_should_load_from_cache()
{
    $lastUpdated = get_option('bloggerbucks_links_last_updated', 0);

    if ($lastUpdated > (time() - BLOGGERBUCKS_LINKS_TIME_TO_CACHE)) {
        return true;
    }

    return false;
}

/**
 * Load links from cache
 *
 * @return mixed|void
 */
function bloggerbucks_links_load_from_cache()
{
    return get_option('bloggerbucks_links_cache', []);
}

/**
 * Clear cache
 */
function bloggerbucks_links_clear_cache()
{
    update_option('bloggerbucks_links_last_updated', 0);
}