<?php

class BloggerBucksApiException extends Exception
{
    /**
     * The url to the api that was made
     *
     * @var int
     */
    protected $url;

    /**
     * BloggerBucksApiException constructor.
     *
     * @param string $message
     * @param int $url
     * @internal param Exception|int $code
     * @internal param Exception $previous
     */
    public function __construct($message, $url = null)
    {
        $this->url = $url;

        parent::__construct($message);
    }

    /**
     * Get the url
     *
     * @return int
     */
    public function getUrl()
    {
        return $this->url;
    }
}