<?php

class BloggerBucksLinksApi
{
    /**
     * API token
     *
     * @var
     */
    protected $token;

    /**
     * BloggerBucksLinksApi constructor.
     */
    public function __construct()
    {
        $this->getToken();
    }

    /**
     * Get links
     *
     * @return mixed
     */
    public function getLinks()
    {
        $data = $this->makeApiCall('links');

        return $data->links;
    }

    /**
     * Get the token
     *
     * @throws Exception
     */
    protected function getToken()
    {
        $options = get_option('bloggerbucks_links');

        if (empty($options['api_token'])) {
            throw new BloggerBucksApiException('BloggerBucks links API token not set.');
        }

        $this->token = $options['api_token'];
    }

    /**
     * Generate the api url
     *
     * @param null $link
     * @return string
     */
    protected function apiUrl($link = null)
    {
        $url = BLOGGERBUCKS_LINKS_API_URL . '/api';

        if (!empty($link)) {
            $url .= '/' . $link;
        }

        $url .= '?api_token=' . $this->token;

        return $url;
    }

    /**
     * Make an api call and return the data
     *
     * @param $link
     * @return mixed
     * @throws BloggerBucksApiException
     */
    protected function makeApiCall($link)
    {
        $url = $this->apiUrl($link);

        $handle = curl_init($url);

        curl_setopt($handle,  CURLOPT_RETURNTRANSFER, TRUE);
        curl_setopt($handle,  CURLOPT_TIMEOUT, 3);

        /* Get the HTML or whatever is linked in $url. */
        $response = curl_exec($handle);
        $httpCode = curl_getinfo($handle, CURLINFO_HTTP_CODE);

        curl_close($handle);

        /* Check for 404 (file not found). */
        if ($httpCode != 200) {
            throw new BloggerBucksApiException('Could not reach API', $url);
        }

        if (empty($response)) {
            throw new BloggerBucksApiException('Empty API response', $url);
        }

        if (! $response = json_decode($response)) {
            throw new BloggerBucksApiException('Invalid JSON response', $url);
        }

        if (! isset($response->success) || ! $response->success) {
            throw new BloggerBucksApiException('API call error: ' . $response->message, $url);
        }

        return $response->data;
    }
}