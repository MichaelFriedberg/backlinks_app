<?php
/*
Plugin Name: BloggerBucks
*/

defined( 'ABSPATH' ) or die( 'Directly executing disallowed!' );

define('BLOGGERBUCKS_LINKS_API_URL', 'http://bloggerbucks.org');
define('BLOGGERBUCKS_LINKS_TIME_TO_CACHE', 60*60);

require_once(plugin_dir_path(__FILE__) . 'BloggerBucksLinksApi.php');
require_once(plugin_dir_path(__FILE__) . 'BloggerBucksApiException.php');
require_once(plugin_dir_path(__FILE__) . 'functions.php');
require_once(plugin_dir_path(__FILE__) . 'options.php');
require_once(plugin_dir_path(__FILE__) . 'widget.php');