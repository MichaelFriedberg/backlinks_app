<?php

defined( 'ABSPATH' ) or die( 'Directly executing disallowed!' );

add_option('bloggerbucks_links', [
    'api_token' => '',
    'debug_mode' => 0
]);

add_option('bloggerbucks_links_cache', []);
add_option('bloggerbucks_links_last_updated', '');

add_action('admin_init', 'bloggerbucks_links_options_init' );
add_action('admin_menu', 'bloggerbucks_links_options_add_page');

// Init plugin options to white list our options
function bloggerbucks_links_options_init(){
    register_setting( 'bloggerbucks_links_options', 'bloggerbucks_links', 'bloggerbucks_links_options_validate' );
}

// Add menu page
function bloggerbucks_links_options_add_page() {
    add_options_page('BloggerBucks Options', 'BloggerBucks', 'manage_options', 'bloggerbucks_links_options', 'bloggerbucks_links_options_page');
}

// Draw the menu page itself
function bloggerbucks_links_options_page() {
    ?>
    <div class="wrap">
        <h2>BloggerBucks Options</h2>

        <form method="post" action="options.php">
            <?php settings_fields('bloggerbucks_links_options'); ?>
            <?php $options = get_option('bloggerbucks_links'); ?>

            <table class="form-table">
                <tr valign="top">
                    <th scope="row">API Token</th>
                    <td>
                        <input class="regular-text code" name="bloggerbucks_links[api_token]" type="text" value="<?php echo $options['api_token']; ?>" />
                    </td>
                </tr>
                <tr valign="top">
                    <th scope="row">Debug Mode</th>
                    <td>
                        <input name="bloggerbucks_links[debug_mode]" type="checkbox" value="1" <?php checked('1', $options['debug_mode']); ?> />
                    </td>
                </tr>
                <tr valign="top">
                    <th scope="row">Cache</th>
                    <td>
                        <p>Caching for <?php echo human_time_diff(BLOGGERBUCKS_LINKS_TIME_TO_CACHE, 1) ?></p>
                        <p>Last Updated: <?php echo human_time_diff(get_option('bloggerbucks_links_last_updated'), time()) ?> ago</p>
                        <br>
                        <button class="button" type="submit" name="bloggerbucks_links[clear_cache]" value="1">Clear Cache</button>
                    </td>
                </tr>
            </table>

            <p class="submit">
                <input type="submit" class="button-primary" value="<?php _e('Save Changes') ?>" />
            </p>
        </form>
    </div>
    <?php
}

// Sanitize and validate input. Accepts an array, return a sanitized array.
function bloggerbucks_links_options_validate($input) {
    // Debug mode value is either 0 or 1
    $input['debug_mode'] = ( $input['debug_mode'] == 1 ? 1 : 0 );

    $input['api_token'] = trim($input['api_token']);

    if (isset($input['clear_cache'])) {
        bloggerbucks_links_clear_cache();
    }

    return $input;
}
